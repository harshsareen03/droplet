from distutils.log import error

from django.shortcuts import redirect, render

from django.contrib.auth import logout
# def signup(request):

#     return render(request, 'account/signup.html')







# def logouts(request):
#     logout(request)
#     return render(request,'account/login.html')

        
    
   
        
# Create your views here.
