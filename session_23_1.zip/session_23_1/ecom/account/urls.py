from django.urls import path
# from .views import Signup
# from . import views
urlpatterns = [

    # path('logouts/', views.logouts, name='logouts')
]
